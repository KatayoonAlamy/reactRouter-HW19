import { useState } from "react";

export default function HomePage() {
  const predefinedNumber = 4;

  const [inputValue, setInputValue] = useState(0);
  const [Boxcolor, setBoxColor] = useState("bg-blue-950");

  const handleInputChange = (event) => {
    const value = event.target.value;
    setInputValue(value); 
  };

  const handleCheckClick = () => {
    console.log(inputValue); 
    const numberInput = Number(inputValue);  
      
    setBoxColor(  
      numberInput > predefinedNumber   
        ? 'yellow'   
        : numberInput < predefinedNumber   
          ? 'blue'   
          : 'transparent')
  };

  return (
    <div className="flex flex-col gap-8 justify-center items-center bg-gray-200 w-64 ml-[600px] mt-36 py-10 rounded-xl">
      <span className = {`w-12 h-10 text-3xl text-center ${Boxcolor} text-white rounded`} >
        {predefinedNumber}
      </span>

      <input
        type="number"
        placeholder="Enter your gusse..."
        className="px-4 py-2"
        value={inputValue}
        onChange={handleInputChange}
      />

      <button
        className="w-14 h-8 bg-orange-400 rounded-full"
        onClick={handleCheckClick}
      >
        check
      </button>
    </div>
  );
}
